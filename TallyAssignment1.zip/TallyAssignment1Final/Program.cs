﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static TallyAssignment1Final.Program;

namespace TallyAssignment1Final
{
    internal class Program
    {
        static List<Student> studentslist = new List<Student>();
        static void Main(string[] args)
        {
            Student student1 = new Student()
            {
                Name = "Punith",
                StudId = 1,
                Address = "Kunigal ",
                Class = "SSLC",
                Subjects = new List<Subject>()
                {
                     new Subject()
                     {
                          SubId = 1,
                          Name = "Kannada",
                          MaxMarks = 100,
                          MarksObtained = 86
                     },
                     new Subject()
                     {
                          SubId = 2,
                          Name = "English",
                          MaxMarks = 100,
                          MarksObtained = 86
                     },
                    new Subject()
                     {
                          SubId = 3,
                          Name = "Hindi  ",
                          MaxMarks = 100,
                          MarksObtained = 98
                     },
                    new Subject()
                     {
                          SubId = 4,
                          Name = "Science",
                          MaxMarks = 100,
                          MarksObtained = 82
                     },
                    new Subject()
                     {
                          SubId = 5,
                          Name = "Social ",
                          MaxMarks = 100,
                          MarksObtained = 79
                     }
                }
            };
            studentslist.Add(student1);

            Student student2 = new Student()
            {
                Name = "Nanda ",
                StudId = 2,
                Address = "Banglore",
                Class = "SSLC",
                Subjects = new List<Subject>()
                {
                     new Subject()
                     {
                          SubId = 1,
                          Name = "Kannada",
                          MaxMarks = 100,
                          MarksObtained = 95
                     },
                     new Subject()
                     {
                          SubId = 2,
                          Name = "English",
                          MaxMarks = 100,
                          MarksObtained = 81
                     },
                     new Subject()
                     {
                          SubId = 3,
                          Name = "Hindi  ",
                          MaxMarks = 100,
                          MarksObtained = 95
                     },
                    new Subject()
                     {
                          SubId = 4,
                          Name = "Science",
                          MaxMarks = 100,
                          MarksObtained = 85
                     },
                    new Subject()
                     {
                          SubId = 5,
                          Name = "Social ",
                          MaxMarks = 100,
                          MarksObtained = 80
                     },
                }
            };
            studentslist.Add(student2);
            Student student = new Student();
            bool exit = true;
            try
            {
                while (exit)
                {
                    Console.WriteLine("\n------------------------------------Menu--------------------------------------");
                    Console.WriteLine("1--Add     2--Display     3--DisplayAll     4--Delete     5--Update     6--Exit");
                    string options = Console.ReadLine();
                    int option = Convert.ToInt32(CheckInteger(options));
                    switch (option)
                    {
                        case 1:
                            AddStudent(student);
                            break;

                        case 2:
                            Console.WriteLine("Enter the Id to display:");
                            string studIdDisC = Console.ReadLine();
                            int studIdDis = Convert.ToInt32(CheckInteger(studIdDisC));
                            bool idFoundDis = FindId(studIdDis);
                            if (idFoundDis == false)
                            {
                                Console.WriteLine("StudentId Not found Enter the Valid Id");
                                break;
                            }
                            Display(studIdDis);
                            break;

                        case 3:
                            DisplayAll();
                            break;

                        case 4:
                            Console.WriteLine("Enter the id to delete:");
                            string studIdDelC = Console.ReadLine();
                            int studIdDel = Convert.ToInt32(CheckInteger(studIdDelC));
                            bool idFoundDel = FindId(studIdDel);
                            if (idFoundDel == false)
                            {
                                Console.WriteLine("StudentId Not found Enter the Valid Id");
                                break;
                            }
                            DeleteStudent(studIdDel);
                            break;

                        case 5:
                            Console.WriteLine("Enter the id to update:");
                            string studIdUpdC = Console.ReadLine();
                            int studIdUpd = Convert.ToInt32(CheckInteger(studIdUpdC));
                            bool idFoundUpd = FindId(studIdUpd);
                            if (idFoundUpd == false)
                            {
                                Console.WriteLine("StudentId Not found Enter the Valid Id");
                                break;
                            }
                            UpdateStudent(studIdUpd);
                            break;

                        case 6:
                            exit = false;
                            break;

                        default:
                            Console.WriteLine("Please Enter the options from 1 - 6");
                            break;
                    }
                }
                Console.ReadKey();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message+"Enter the valid type");
            }
        }
        public static void AddStudent(Student student)
        {
            int id;
            try
            {
                var StudidNo = (from stu in studentslist
                                select stu).LastOrDefault();
                if(StudidNo == null)
                {
                    id = 1;
                }
                else
                {
                    id = StudidNo.StudId + 1;
                }
                Console.WriteLine("Enter the Name of student:");
                string name = Console.ReadLine();
                while(string.IsNullOrWhiteSpace(name) || name.Any(c=>char.IsDigit(c)) || name.Length <= 3)
                {
                    Console.WriteLine("The length of Name should be > 3 and valid type");
                    name = Console.ReadLine();
                }
                Console.WriteLine("Enter the Address:");
                string address = Console.ReadLine();
                while (string.IsNullOrWhiteSpace(address) || address.Any(c => char.IsDigit(c)) || address.Length <= 4)
                {
                    Console.WriteLine("The length of Address should be > 4 and valid type");
                    address = Console.ReadLine();
                }
                Console.WriteLine("Enter the Class:");
                string section = Console.ReadLine();
                while (string.IsNullOrWhiteSpace(section))
                {
                    Console.WriteLine("The Section should be single character");
                    section = Console.ReadLine();
                }
                Console.WriteLine("Enter the name of subject1");
                string sub1Check = Console.ReadLine();
                string sub1 = ValidateSubject(sub1Check);
                Console.WriteLine("Enter the name of subject2");
                string sub2Check = Console.ReadLine();
                string sub2 = ValidateSubject(sub2Check);
                Console.WriteLine("Enter the name of subject3");
                string sub3Check = Console.ReadLine();
                string sub3 = ValidateSubject(sub3Check);
                Console.WriteLine("Enter the name of subject4");
                string sub4Check = Console.ReadLine();
                string sub4 = ValidateSubject(sub4Check);
                Console.WriteLine("Enter the name of subject5");
                string sub5Check = Console.ReadLine();
                string sub5 = ValidateSubject(sub5Check);
                Console.WriteLine($"Enter the Marks Obtained in {sub1}:");
                int marksObtainedSub1Check = Convert.ToInt32(Console.ReadLine());
                int marksObtainedSub1 = ValidateMarks(marksObtainedSub1Check);
                Console.WriteLine($"Enter the Marks Obtained in {sub2}:");
                int marksObtainedSub2Check = Convert.ToInt32(Console.ReadLine());
                int marksObtainedSub2 = ValidateMarks(marksObtainedSub2Check);
                Console.WriteLine($"Enter the Marks Obtained in {sub3}:");
                int marksObtainedSub3Check = Convert.ToInt32(Console.ReadLine());
                int marksObtainedSub3 = ValidateMarks(marksObtainedSub3Check);
                Console.WriteLine($"Enter the Marks Obtained in {sub4}:");
                int marksObtainedSub4Check = Convert.ToInt32(Console.ReadLine());
                int marksObtainedSub4 = ValidateMarks(marksObtainedSub4Check);
                Console.WriteLine($"Enter the Marks Obtained in {sub5}:");
                int marksObtainedSub5Check = Convert.ToInt32(Console.ReadLine());
                int marksObtainedSub5 = ValidateMarks(marksObtainedSub5Check);
                Console.WriteLine("Student Added successfuly");
                Console.WriteLine("----------------------------------");
                student = new Student()
                {
                    Name = name,
                    StudId = id,
                    Address = address,
                    Class = section,
                    Subjects = new List<Subject>()
                    {
                        new Subject()
                        {
                            SubId = 1,
                            Name = sub1,
                            MaxMarks = 100,
                            MarksObtained = marksObtainedSub1
                        },     
                        new Subject()
                        {
                            SubId = 2,
                            Name = sub2,
                            MaxMarks = 100,
                            MarksObtained = marksObtainedSub2
                        },
                        new Subject()
                        {
                            SubId = 3,
                            Name = sub3,
                            MaxMarks = 100,
                            MarksObtained = marksObtainedSub3
                        },
                        new Subject()
                        {
                            SubId = 4,
                            Name = sub4,
                            MaxMarks = 100,
                            MarksObtained = marksObtainedSub4
                        },
                        new Subject()
                        {
                            SubId = 5,
                            Name = sub5,
                            MaxMarks = 100,
                            MarksObtained = marksObtainedSub5
                        }
                    }
                };
                studentslist.Add(student);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void DisplayAll()
        {
            if (studentslist.Count == 0)
            {
                Console.WriteLine("No items in the list");
            }
            else
            {
                Console.WriteLine("-------------Student Details--------------                 ----------------Subjact Score--------------      ");
                Console.WriteLine("StudentId    Name          Address     Class          SubjectId     SubjectName    MaxMarks     MarksObtained");
                foreach (Student student in studentslist)
                {
                    Console.Write(" "+student.StudId + "           " + student.Name + "        " + student.Address + "      " + student.Class + "                ");
                    foreach (var subject in student.Subjects)
                    {
                        Console.Write(" "+ subject.SubId + "           " + subject.Name + "        "
                       + subject.MaxMarks + "             " + subject.MarksObtained);
                        Console.Write("                                                                          ");
                    }
                    Console.WriteLine();
                }
            }
        }
        public static void Display(int StudentId)
        {
            var student = from stud in studentslist
                          where stud.StudId == StudentId
                          select stud;
            Console.WriteLine("-------------Student Details--------------                 ----------------Subjact Score--------------      ");
            Console.WriteLine("StudentId    Name          Address     Class          SubjectId     SubjectName    MaxMarks     MarksObtained");
            foreach (Student stud in student)
            {
                Console.Write(" " + stud.StudId + "           " + stud.Name + "        " + stud.Address + "      " + stud.Class + "                "); 
                foreach (var subject in stud.Subjects)
                {
                    Console.Write(" " + subject.SubId + "           " + subject.Name + "        "
                       + subject.MaxMarks + "             " + subject.MarksObtained);
                    Console.Write("                                                                          ");
                }
            }
        }
        public static void UpdateStudent(int studentId)
        {
            var student = (from stud in studentslist
                           where stud.StudId == studentId
                           select stud);
            foreach (var stud in student)
            {
                Console.WriteLine("Enter the Name of student:");
                string name = Console.ReadLine();
                while (string.IsNullOrWhiteSpace(name) || name.Any(c => char.IsDigit(c)) || name.Length <= 3)
                {
                    Console.WriteLine("The length of Name should be > 3 and valid type");
                    name = Console.ReadLine();
                }
                Console.WriteLine("Enter the Address:");
                string address = Console.ReadLine();
                while (string.IsNullOrWhiteSpace(address) || address.Any(c => char.IsDigit(c)) || address.Length <= 4)
                {
                    Console.WriteLine("The length of Address should be > 4 and valid type");
                    address = Console.ReadLine();
                }
                Console.WriteLine("Enter the Class:");
                string section = Console.ReadLine();
                while (string.IsNullOrWhiteSpace(section))
                {
                    Console.WriteLine("The Section should be single character");
                    section = Console.ReadLine();
                }
                Console.WriteLine("Enter the name of subject1");
                string sub1Check = Console.ReadLine();
                stud.Subjects[0].Name = ValidateSubject(sub1Check);
                Console.WriteLine("Enter the name of subject2");
                string sub2Check = Console.ReadLine();
                stud.Subjects[1].Name = ValidateSubject(sub2Check);
                Console.WriteLine("Enter the name of subject3");
                string sub3Check = Console.ReadLine();
                stud.Subjects[2].Name = ValidateSubject(sub3Check);
                Console.WriteLine("Enter the name of subject4");
                string sub4Check = Console.ReadLine();
                stud.Subjects[3].Name = ValidateSubject(sub4Check);
                Console.WriteLine("Enter the name of subject5");
                string sub5Check = Console.ReadLine();
                stud.Subjects[4].Name = ValidateSubject(sub5Check);
                Console.WriteLine($"Enter the Marks Obtained in {stud.Subjects[0].Name}:");
                int marksObtainedSub1Check = Convert.ToInt32(Console.ReadLine());
                stud.Subjects[0].MarksObtained = ValidateMarks(marksObtainedSub1Check);
                Console.WriteLine($"Enter the Marks Obtained in {stud.Subjects[1].Name}:");
                int marksObtainedSub2Check = Convert.ToInt32(Console.ReadLine());
                stud.Subjects[1].MarksObtained = ValidateMarks(marksObtainedSub2Check);
                Console.WriteLine($"Enter the Marks Obtained in {stud.Subjects[2].Name}:");
                int marksObtainedSub3Check = Convert.ToInt32(Console.ReadLine());
                stud.Subjects[2].MarksObtained = ValidateMarks(marksObtainedSub3Check);
                Console.WriteLine($"Enter the Marks Obtained in {stud.Subjects[3].Name}:");
                int marksObtainedSub4Check = Convert.ToInt32(Console.ReadLine());
                stud.Subjects[3].MarksObtained = ValidateMarks(marksObtainedSub4Check);
                Console.WriteLine($"Enter the Marks Obtained in {stud.Subjects[4].Name}:");
                int marksObtainedSub5Check = Convert.ToInt32(Console.ReadLine());
                stud.Subjects[4].MarksObtained = ValidateMarks(marksObtainedSub5Check);
                Console.WriteLine("Student Data Updated successfuly");
                Console.WriteLine("----------------------------------");
                stud.Name = name;
                stud.Address = address;
                stud.Class = section;
            }
        }
        public static void DeleteStudent(int studentId)
        {
            IEnumerable<int> indexes = from stud in studentslist
                                       where stud.StudId == studentId
                                       select studentslist.IndexOf(stud);
            studentslist.RemoveAt(indexes.FirstOrDefault());
            Console.WriteLine("Student Data Deleted successfuly");
        }
        public static bool FindId(int studId)
        {
            var findid = (from studs in studentslist
                          where studs.StudId == studId
                          select studs).Any();
            return findid;
        }
        public static int ValidateMarks(int marks)
        {
            while (marks > 100 || marks < 1)
            {
                Console.WriteLine("The value should be between 1-100");
                marks = Convert.ToInt32(Console.ReadLine());
            }
            return marks;
        }
        public static string CheckInteger(string value)
        {
            int n;
            while (!int.TryParse(value, out n))
            {
                Console.WriteLine("Enter the integer value");
                value = Console.ReadLine();
            }
            return value;
        }
        public class Student
        {
            public int StudId { get; set; }
            public string Name { get; set; }
            public string Address { get; set; }
            public string Class { get; set; }
            public List<Subject> Subjects { get; set; }
        }
        public class Subject
        {
            public int SubId { get; set; }
            public string Name { get; set; }
            public int MaxMarks { get; set; }
            public int MarksObtained { get; set; }
        }
        public static string ValidateSubject(string value)
        {
            while(!value.All(Char.IsLetter))
            {
                Console.WriteLine("Not valid !! Enter only the charecters");
                value=Console.ReadLine();
            }
            return value;
        }
    }
}
